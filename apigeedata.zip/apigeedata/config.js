exports.organization = 'parameswari'
exports.application = 'entertainment'
exports.clientId = 'b3U6bpLKGmYcEear1slQk1ceZA'
exports.clientSecret = 'b3U6QDkH1m1IsZSM7p0LXOmbaEKdTQk'
exports.tokenExpiration = 60000
exports.logging = true